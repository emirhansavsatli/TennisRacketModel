# TennisRacket > 2023-08-17 11:56pm
https://universe.roboflow.com/itu-tsv9v/tennisracket-coark

Provided by a Roboflow user
License: CC BY 4.0

